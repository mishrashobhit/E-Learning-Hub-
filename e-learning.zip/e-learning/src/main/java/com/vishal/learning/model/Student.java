
package com.vishal.learning.model;

import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.util.Base64;

import org.springframework.web.bind.annotation.CrossOrigin;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Author : visha
 * Date :Feb 1, 2025
 * Time :12:38:28 PM
 * Project :e-learning 
 */

@CrossOrigin(origins = "http://localhost:3000/")
@Entity
@Table(name="students")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY,generator = "std_seq")
	@SequenceGenerator(name="std_seq",initialValue = 101,allocationSize = 1)
	@Column(name="stdId")
	
	private Long id;

	@Column(unique=true,nullable = false)    //Unique Constraint
	private String email;

	@Column(name="first_name",nullable = false) //not null constraint
	private String fname;

	@Column(name="last_name",nullable = false)
	private String lname;

	@NotBlank(message = "Password cannot be blank")
	@Size(min = 8, max = 255, message = "Password must be between 8 and 255 characters")
	@Column(name = "password", nullable = false)
	private String password;

	@JsonFormat(pattern="yyyy-MM-dd")
	@Column(nullable = false)
	private Date dob;

	@Column(name="phone",unique = true,nullable = false)
	private String phoneNo;
	

	/*Primary Key - Foreign Key Relationship
	 * Model 1-1 Bi-Directional Mapping b/n Dealer & Address
	 * */
	@OneToOne(mappedBy = "student", cascade = CascadeType.ALL)
	private Address address; //has-a relationship


	public Student() {
		
	}


	public Student(Long id, String email, String fname, String lname,
			@NotBlank(message = "Password cannot be blank") @Size(min = 8, max = 255, message = "Password must be between 8 and 255 characters") String password,
			Date dob, String phoneNo) {
		super();
		this.id = id;
		this.email = email;
		this.fname = fname;
		this.lname = lname;
		this.password = password;
		this.dob = dob;
		this.phoneNo = phoneNo;
	}


	public Student(Long id, String email, String fname, String lname,
			@NotBlank(message = "Password cannot be blank") @Size(min = 8, max = 255, message = "Password must be between 8 and 255 characters") String password,
			Date dob, String phoneNo, com.vishal.learning.model.Address address) {
		super();
		this.id = id;
		this.email = email;
		this.fname = fname;
		this.lname = lname;
		this.password = password;
		this.dob = dob;
		this.phoneNo = phoneNo;
		this.address = address;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public String getLname() {
		return lname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		Base64.Encoder encoder = Base64.getEncoder();  //Use Base64 class for password Encryption
        String normalString = password;
        String encodedString = encoder.encodeToString(   // encrypt password in database field
        normalString.getBytes(StandardCharsets.UTF_8) );
        this.password = encodedString;
	}


	public Date getDob() {
		return dob;
	}


	public void setDob(Date dob) {
		this.dob = dob;
	}


	public String getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}
	

}
