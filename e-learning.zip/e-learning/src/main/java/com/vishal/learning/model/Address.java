
package com.vishal.learning.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

/**
 * Author : vishal
 * Date :Feb 1, 2025
 * Time :7:47:31 PM
 * Project :e-learning
 */

@RequiredArgsConstructor
@NoArgsConstructor
@Data // Getter +Setter+toString()
@Entity
public class Address {
	
	@Id  //primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) //Auto Numbering from 1
    private Long addressId;
	
	private @NonNull String street;
	private @NonNull String city;
	private  int pincode;
	
	/* Foreign key Relationship*/
	@OneToOne             //One-One Mapping
	@JoinColumn(name="student_id") //Foreign key field
	private Student student; //Reference Class Object
 
	public Address(@NonNull String street, @NonNull String city, int pincode) {
		super();
		this.street = street;
		this.city = city;
		this.pincode = pincode;
	}

}
