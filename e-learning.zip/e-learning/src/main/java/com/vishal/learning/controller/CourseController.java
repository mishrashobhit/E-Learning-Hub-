
package com.vishal.learning.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vishal.learning.exception.CourseNotFoundException;
import com.vishal.learning.model.Course;
import com.vishal.learning.service.CourseService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


/**
 * Author : vishal
 * Date :Feb 1, 2025
 * Time :2:35:35 PM
 * Project :e-learning 
 */
@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/api")

public class CourseController {
	
	@Autowired
	private CourseService courseService; 
	
	//Open PostMan, make a POST Request - http://localhost:9091/learning/api/course
	//Select body -> raw -> JSON 
	//Insert JSON Course object.
	
	@PostMapping("/course")
	public ResponseEntity<Course> saveCourse(@Validated @RequestBody Course c) {
		try {
			Course cs= courseService.saveCourse(c);
			return ResponseEntity.status(HttpStatus.CREATED).body(cs);
		}
		catch(Exception ex) {
			ex.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}
	
	//Open PostMan/Browsers, make a Get Request - http://localhost:9091/learning/api/course
	@GetMapping("/course")
	public ResponseEntity<List<Course>> displayAllCourses() {

		try {
			List<Course> courses=courseService.listAll();//Invoke listAll() service method
			return ResponseEntity.ok(courses);
		}
		catch(Exception e) {
			e.printStackTrace();
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		}
	}
	
	//Open PostMan/Browser, make a GET Request - http://localhost:9091/learning/api/course/104
		//Exception handling is done with Custom Exceptions
		@GetMapping("/course/{cid}")
		public ResponseEntity<Course> getCourseById(@PathVariable(value="cid") Long cId) 
				throws CourseNotFoundException{

			Course c=courseService.getSingleCourse(cId).orElseThrow(() ->
			new  CourseNotFoundException("Course Not Found for this Id : "+cId)); //invokes constructor of ResourceNotFoundException class

			return ResponseEntity.ok(c);
		}

	//Open PostMan, make a PUT Request - http://localhost:9091/learning/api/course/102
			//Select body -> raw -> JSON 
			//Update JSON Course object with new Values.
	
			@PutMapping("/course/{cid}")
			public ResponseEntity<Course> updateProduct(@PathVariable(value="cid") Long cId,
					@Validated @RequestBody Course c) throws CourseNotFoundException {

				Course course=courseService.getSingleCourse(cId).
						orElseThrow(() -> new CourseNotFoundException("Course Not Found for this Id :"+cId));
			
				//Update Course with new values
				course.setName(c.getName());
				course.setPrice(c.getPrice());
				course.setDescription(c.getDescription());

				final Course updatedCourse=courseService.saveCourse(c); // invokes service layer method
				return ResponseEntity.ok().body(updatedCourse);
			}
			
			//Open PostMan, make a DELETE Request - http://localhost:9091/learning/api/course/102
			@DeleteMapping("/course/{cid}")
			public ResponseEntity<Map<String,Boolean>> deleteCourse(@PathVariable(value="cid") Long cId) 
					throws CourseNotFoundException {

				courseService.getSingleCourse(cId).  // invokes service layer method
				orElseThrow(() -> new CourseNotFoundException("Course Not Found for this Id :"+cId));

				courseService.deleteCourse(cId); // invokes service layer method

				Map<String,Boolean> response=new HashMap<>(); //Map Stores Data in key-value pairs
				response.put("Deleted", Boolean.TRUE);
				
				return ResponseEntity.ok(response);
			}
			
			/*
			 * In Spring Boot, RequestParam is a standard annotation used to inject request parameters 
			 * from a web request into a controller method. 
			 * It is often used to extract data from HTTP requests, such as form parameters or query parameters. 
			 * When a controller method is annotated with @RequestParam, the method parameter is 
			 * bound to the value of the corresponding request parameter. 
			 * For example, @RequestParam("name") String name would bind the name method parameter to 
			 * the value of the "name" request parameter.
			 * 	
			 * ResponseEntity<?> indicates that the body of the response can be any type, 
			 * making it a generic reusable class.
			 */
			// GET Request - http://localhost:9091/learning/api/search?name=java 
			@GetMapping("/search")
		    public ResponseEntity<?> searchCoursesByName(@RequestParam("name") String name) {
		        try {
		            List<Course> course = courseService.searchCourseByName(name);
		            
		            if (course.isEmpty()) {
		                return new ResponseEntity<>("No Courses found with the given name.", HttpStatus.NOT_FOUND);
		            }
		            
		            return new ResponseEntity<>(course, HttpStatus.OK);
		        } catch (Exception ex) {
		        	//database error
		            return new ResponseEntity<>("An error occurred while searching for courses.", HttpStatus.INTERNAL_SERVER_ERROR);
		        }
		    }
			
			// Client (POSTMAN/Browser) --> request --->FC --> Controller ---> Service --> Repository --> JPA --> DB(MySQL)
			
			// DB - Response --> JPA --> Repository --> Service ---> Controller ---> FC ---> PostMan/Browser
			
}
