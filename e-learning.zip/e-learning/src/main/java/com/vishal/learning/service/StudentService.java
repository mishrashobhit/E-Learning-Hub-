
package com.vishal.learning.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vishal.learning.model.Student;
import com.vishal.learning.model.StudentAndAddressProjection;
import com.vishal.learning.repository.StudentRepository;

/**
 * Author : vishal
 * Date :Feb 1, 2025
 * Time :10:35:03 PM
 * Project :e-learning
 */

@Service
public class StudentService {
	
	@Autowired
	private StudentRepository srepo;
	
	public Student registerStudent(Student s) {
		return srepo.save(s); // invokes pre-defined methods of JPA repo
	}
	
	public Optional<Student> loginStudent(String email) {
		return srepo.findByEmail(email); //Invokes custom method of JPA repo
	}
	
	public List<StudentAndAddressProjection> getStudentInfo() {
		return srepo.findSelectedFieldsFromStudentAndAddress(); //Invokes Custom Query method
	}
//	
//	// StudentService.java
//
//	public Student updateStudent(Student student) {
//	    return srepo.save(student);
//	}
//
//	public boolean deleteStudent(Long studentId) {
//	    try {
//	        srepo.deleteById(studentId);
//	        return true;
//	    } catch (Exception e) {
//	        return false;
//	    }
//	}
//
//	public List<Student> searchStudentByName(String name) {
//	    return srepo.findByNameContainingIgnoreCase(name);
//	}
//
//	/**
//	 * @param studentId
//	 * @return
//	 */
//	public Optional<Student> getStudentById(Long studentId) {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
