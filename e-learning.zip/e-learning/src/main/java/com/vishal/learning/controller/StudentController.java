
package com.vishal.learning.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vishal.learning.exception.CourseNotFoundException;
import com.vishal.learning.model.Address;
import com.vishal.learning.model.Student;
import com.vishal.learning.model.StudentAndAddressProjection;
import com.vishal.learning.service.StudentService;

/**
 * Author : vishal
 * Date :Feb 1, 2025
 * Time :10:41:53 PM
 * Project :e-learning
 * 
 * Controller for Registration & Login process of the Student
 */
@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/api")
public class StudentController {
	
	private final StudentService studentService;

	//DI using Constructors
	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}


	//Open PostMan, make a POST Request - http://localhost:9091/learning/api/register
		//Select body -> raw -> JSON 
		//Insert JSON Student object.
		@PostMapping("/register")
		public ResponseEntity<String> createStudent(@Validated @RequestBody Student student){
			try {
				Address address=student.getAddress(); //get data from secondary Table

				//Establish bi-directional Mapping
				address.setStudent(student);
				student.setAddress(address);

				Student registeredDealer=studentService.registerStudent(student); //save Student details
				if(registeredDealer !=null) {
					return ResponseEntity.ok("Registration Successfull");
				}else {
					return ResponseEntity.badRequest().body("Registration Failed");
				}
			}catch(Exception e) {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).
						body("An Error Occurred :"+e.getMessage());
			}
		}


		 //Open PostMan, make a POST Request -http://localhost:9091/learning/api/login
		//Select body -> raw -> JSON 
		//Insert JSON Student object with email & password.
	@PostMapping("/login")
	public ResponseEntity<Boolean> loginStudent(@Validated @RequestBody Student student) 
//	public ResponseEntity<String> loginStudent(@Validated @RequestBody Student student) // is used to print string message i.e login successful
			throws CourseNotFoundException
	{
		Boolean isLogin=false;
//		String isLogin = null;
		String email = student.getEmail();
		String password =  student.getPassword();
		
		Student s= studentService.loginStudent(email).orElseThrow(() -> //Invokes loginDealer() method with email parameter
		new CourseNotFoundException("Student doen't Exists :: " +email));
		
		if(email.equals(s.getEmail()) && password.equals(s.getPassword())) {
			isLogin=true;
//			isLogin ="login Successful";
		}
		return ResponseEntity.ok(isLogin);
		
	}
	
	//Open Postman/Browser - http://localhost:9091/learning/api/student
		@GetMapping("/student")
		public ResponseEntity<List<StudentAndAddressProjection>> getStudentInfo(){
			try {
				List<StudentAndAddressProjection> selectedFields=studentService.getStudentInfo();
				
				return ResponseEntity.ok(selectedFields);
			}catch(Exception e) {
				e.printStackTrace();
				
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
			}
		}
		
//
//	    // PUT: Update a student's information by their ID
//	    @PutMapping("/student/{id}")
//	    public ResponseEntity<Student> updateStudent(@PathVariable("id") Long studentId, @RequestBody Student student) {
//	        try {
//	            Optional<Student> existingStudentOpt = studentService.getStudentById(studentId);
//	            if (existingStudentOpt.isPresent()) {
//	                student.setId(studentId); // Ensure the student ID remains unchanged
//	                Student updatedStudent = studentService.updateStudent(student);
//	                return ResponseEntity.ok(updatedStudent);
//	            } else {
//	                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//	            }
//	        } catch (Exception e) {
//	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
//	        }
//	    }
//
//	    // DELETE: Delete a student by their ID
//	    @DeleteMapping("/student/{id}")
//	    public ResponseEntity<String> deleteStudent(@PathVariable("id") Long studentId) {
//	        try {
//	            boolean isDeleted = studentService.deleteStudent(studentId);
//	            if (isDeleted) {
//	                return ResponseEntity.ok("Student deleted successfully");
//	            } else {
//	                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student not found");
//	            }
//	        } catch (Exception e) {
//	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred: " + e.getMessage());
//	        }
//	    }
//
//	    // GET: Search students by name
//	    @GetMapping("/student/search/{name}")
//	    public ResponseEntity<List<Student>> searchStudentByName(@PathVariable("name") String name) {
//	        try {
//	            List<Student> students = studentService.searchStudentByName(name);
//	            if (students.isEmpty()) {
//	                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
//	            } else {
//	                return ResponseEntity.ok(students);
//	            }
//	        } catch (Exception e) {
//	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
//	        }
//	    }
//	
}
