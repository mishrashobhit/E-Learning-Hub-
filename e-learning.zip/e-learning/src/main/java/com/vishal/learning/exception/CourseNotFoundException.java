
package com.vishal.learning.exception;
/**
 * Author : vishal
 * Date :Feb 1, 2025
 * Time :3:39:34 PM
 * Project :e-learning 
 * Custom Exception Handling that means exception handled by user
 */

public class CourseNotFoundException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public CourseNotFoundException(String message) {
		super(message);
	}

}
