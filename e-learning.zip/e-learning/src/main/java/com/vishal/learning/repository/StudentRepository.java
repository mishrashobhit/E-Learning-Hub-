
package com.vishal.learning.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.vishal.learning.model.Student;
import com.vishal.learning.model.StudentAndAddressProjection;

/**
 * Author : vishal
 * Date :Feb 1, 2025
 * Time :10:27:52 PM
 * Project :e-learning 
 * 
 * Repository for Student Registration & Login
 */

public interface StudentRepository extends JpaRepository<Student, Long>{
	//By default JpaRepository has pre-defined methods for CRUD operations
	//To fetch a single record based on primary-key field - findById()
	
   // Custom method for Login functionality
	//Custom Methods - To fetch a record/object based on  nonId field - email
	public Optional<Student> findByEmail(String email);
	
//	public Optional<List<Dealer>> findByLname(String lname);
	
	/*
	 * @Query Annotation is used for defining custom queries in Spring Data JPA. 
	 * When you are unable to use the query methods to execute database operations 
	 * then you can use @Query to write a more flexible query to fetch data. 
	 *  
		- @Query Annotation supports both JPQL and native SQL queries.
		- It also supports SpEL expressions.
		- @Param in method arguments to bind query parameter.
		- To define Multiple Joins
	 */
	//Custom Queries - JPQL - Object Oriented Query Language
	@Query("SELECT new com.vishal.learning.model.StudentAndAddressProjection"
			+ "(s.id,s.fname,s.lname,s.phoneNo,"
			+ "s.email,a.street,a.city,a.pincode)"
			+ " FROM Student s JOIN s.address a")
	List<StudentAndAddressProjection> findSelectedFieldsFromStudentAndAddress(); 
	
//	// StudentRepository.java
//	  List<Student> findByNameContainingIgnoreCase(String name);

}
