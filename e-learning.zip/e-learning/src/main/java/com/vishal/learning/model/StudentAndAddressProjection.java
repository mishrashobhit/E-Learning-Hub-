
package com.vishal.learning.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Author : vishal
 * Date :Feb 2, 2025
 * Time :12:30:19 AM
 * Project :e-learning
 * 
 * Model class to perform Inner Join b/n Student & Address classes
 */


@NoArgsConstructor
@AllArgsConstructor
@Data
public class StudentAndAddressProjection {

	private Long id;
	private String fname;
	private String lname;
	private String phoneNo;
	private String email;
	private String street;
	private  String city;
	private  int pincode;
}
