
package com.vishal.learning.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.vishal.learning.model.Course;
import com.vishal.learning.repository.CourseRepository;


/**
 * Author : vishal
 * Date :Feb 1, 2025
 * Time :1:36:24 PM
 * Project :e-learning 
 */

@Service
public class CourseService {

	private final CourseRepository courseRepository;

	public CourseService(CourseRepository courseRepository) {
		this.courseRepository = courseRepository;
	}
	
	public Course saveCourse(Course c) {
		return courseRepository.save(c); //invokes pred-defined method save(c) of JPA Repository
	}
	
	public List<Course> listAll(){
		return courseRepository.findAll(); //invokes pred-defined method findAll() of JPA Repository
	}
	
	// Optional return type is to handle Null Pointer Exception
	   public Optional<Course> getSingleCourse(long cid) {
		   return courseRepository.findById(cid);       //Invokes pre-defined method findById() of JPA repository
	   }
	   
	   public void deleteCourse(long cid) {
		   courseRepository.deleteById(cid); //Invokes pre-defined method deleteById() of JPA repository
	   }
	   
	   public List<Course> searchCourseByName(String name){
		   return courseRepository.findCourseByNameContainingIgnoreCase(name); //Invokes method with custom query
	   }

}
